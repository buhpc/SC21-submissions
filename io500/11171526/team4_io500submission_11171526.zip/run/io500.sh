#!/bin/bash

mpirun -np 960 --hostfile hostfile ./io500 config-scc.ini
