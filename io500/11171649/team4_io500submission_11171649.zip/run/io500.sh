#!/bin/bash
mpirun -np 1440 --hostfile hostfile ./io500 config-scc.ini
